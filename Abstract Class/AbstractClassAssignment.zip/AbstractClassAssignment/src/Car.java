
public class Car extends Vehicle{
	
	private String engineType;
	private boolean manual;
	private int horsepower;
	


	public Car(int wheels, int weight, boolean engine, String name, String engineType, boolean manual, int horsepower) {
		super(wheels, weight, engine, name);
		this.engineType = engineType;
		this.manual = manual;
		this.horsepower = horsepower;
	}

	public String getEngineType() {
		return engineType;
	}

	public void setEngineType(String engineType) {
		this.engineType = engineType;
	}

	public boolean isManual() {
		return manual;
	}

	public void setManual(boolean manual) {
		this.manual = manual;
	}

	public int getHorsepower() {
		return horsepower;
	}

	public void setHorsepower(int horsepower) {
		this.horsepower = horsepower;
	}

	@Override
	public String toString() {
		return "Car [engineType=" + engineType + ", manual=" + manual + ", horsepower=" + horsepower + "]";
	}
	
//----------------------------------------------------------------
	
	@Override
	public void vehicleNoises() {
		System.out.println("*car noises*");	
	}//end vehicleNoises
	
}//end Car
