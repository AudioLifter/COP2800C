
public class Motorcycle extends Vehicle{

	private String engineType;
	private String type;
	
	

	public Motorcycle(int wheels, int weight, boolean engine, String name, String engineType, String type) {
		super(wheels, weight, engine, name);
		this.engineType = engineType;
		this.type = type;
	}

	public String getEngineType() {
		return engineType;
	}

	public void setEngineType(String engineType) {
		this.engineType = engineType;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return "Motorcycle [engineType=" + engineType + ", type=" + type + "]";
	}

	
	//------------------------------------------------------------------------------
	
	@Override
	public void vehicleNoises() {
		System.out.println("*motorcycle noises*");
	}//end vehicleNoises
	
}//end motorcycle
