//Name: Jonathan De La Cruz
//Date: 3/24/10
//Purpose: Abstract Class assignment
import java.util.*;

public class TestClass {

	public static void main(String[] args) {
		
		ArrayList<Vehicle> vehicles = new ArrayList<Vehicle>();
		
		vehicles.add(new Motorcycle(2, 350, true, "Ninja 400", "parallel twin", "standard"));
		vehicles.add(new Car(4, 3000, true, "Honda Accord", "V6", true, 278));
		vehicles.add(new Bicycle(2, 20, false, "Surly Cross-Check", false, "cromoly", "road"));
		vehicles.add(new Bicycle(2, 20, false, "Kilo TT", true, "cromoly", "track"));
		
		
		for(Vehicle vehicle : vehicles) {
			vehicle.vehicleNoises();
		}
		
	}//end main

}//end TestClass
