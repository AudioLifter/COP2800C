
public interface Explodes {
	void exploded();
}
