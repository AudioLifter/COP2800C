
public interface Fire {
	void caughtFire();
}
