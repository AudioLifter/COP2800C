
public interface Noises {
	void vehicleNoises();
	
	
}// end Noises
