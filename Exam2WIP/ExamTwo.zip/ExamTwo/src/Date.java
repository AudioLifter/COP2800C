import java.util.*;


public class Date {
	private int day;
	private int month;
	private int year;
	
	Scanner input = new Scanner(System.in);

	
	public Date() {
		addDate();
	}

	public Date(int day, int month, int year) {
		setDay(day);
		setMonth(month);
		setYear(year);
	}

	public int getDay() {
		return day;
	}

	public void setDay(int day) {
		this.day = day;
	}

	public int getMonth() {
		return month;
	}

	public void setMonth(int month) {
		this.month = month;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	@Override
	public String toString() {
		return "\nDOB: " + month + "/" + day + "/" + year;
	}
	
	//====================================================================================
	
	public void addDate() {
		int day;
		int month;
		int year;
		
		year = Methods.getInt("Please enter the player's year of birth: ");
		month = Methods.getInt("Please enter the player's month of birth: ");
		day = Methods.getInt("Please enter the player's day of birth: ");
		
		setYear(year);
		setMonth(month);
		setDay(day);
		
	}//end addDate
	
}//end Date
